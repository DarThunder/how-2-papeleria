package com.idar.pdvpapeleria.controllers;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import lib.SqlLib;

public class AdministracionEmpleadosController {

    @FXML
    private Button BShowAgregar, BShowEliminar, BShowEditar, BAtras;
    @FXML
    private Pane PAgregar, PEliminar, PEditar;
    @FXML
    private ComboBox<String> CBRol;  // Asegurándote de que es un ComboBox de tipo String
    @FXML
    private TextField TFNombre, TFContraseña;
    @FXML
    private TableView TV1;

    private SqlLib db;

    /**
     * Método de inicialización de la interfaz. Se ejecuta automáticamente
     * cuando la vista es cargada.
     *
     * Inicializa la instancia de la base de datos usando el patrón Singleton.
     *
     * @throws SQLException si ocurre un error al intentar acceder a la base de
     * datos.
     */
    @FXML
    private void initialize() throws SQLException {
        CBRol.getItems().addAll("Dueño", "Administrador", "Cajero"); // Usamos getItems().addAll()
        this.db = SqlLib.getInstance("", "", "");
    }

    /**
     * Cambia la escena actual a la pantalla de inicio de sesión. Este método
     * carga el archivo FXML correspondiente a la pantalla de inicio de sesión y
     * establece esa escena como la activa.
     *
     * @throws IOException si ocurre un error al cargar el archivo FXML
     * correspondiente.
     */
    @FXML
    private void switchToDueñoView() throws IOException {
        File fxmlFile = new File("src/main/resources/scenes/dueñoView.fxml");
        FXMLLoader loader = new FXMLLoader(fxmlFile.toURI().toURL());
        Parent root = loader.load();
        Stage stage = (Stage) BAtras.getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.sizeToScene();
        stage.show();
        stage.centerOnScreen();
    }

    /**
     * Muestra el panel para agregar un empleado y oculta los demás paneles.
     * Este método se utiliza para cambiar la interfaz y permitir al usuario
     * agregar un empleado específico.
     */
    @FXML
    private void mostrarPanelAgregar() {
        PAgregar.setVisible(true);
        PEliminar.setVisible(false);
        PEditar.setVisible(false);
    }

    /**
     * Muestra el panel para eliminar un empleado y oculta los demás paneles.
     * Este método se utiliza para cambiar la interfaz y permitir al usuario
     * eliminar un empleado específico.
     */
    @FXML
    private void mostrarPanelEliminar() {
        PAgregar.setVisible(false);
        PEliminar.setVisible(true);
        PEditar.setVisible(false);
    }

    /**
     * Muestra el panel para editar los datos de un empleado y oculta los demás
     * paneles. Este método se utiliza para cambiar la interfaz y permitir al
     * usuario editar los datos de un empleado específico.
     */
    @FXML
    private void mostrarPanelEditar() {
        PAgregar.setVisible(false);
        PEliminar.setVisible(false);
        PEditar.setVisible(true);
    }

    @FXML
    private boolean verificarCampos() {
        return !TFNombre.getText().trim().isEmpty()
                && !TFContraseña.getText().trim().isEmpty()
                && CBRol.getValue() != null;
    }

    @FXML
    private void agregarEmpleado() throws SQLException {
        if (!verificarCampos()) {
            JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String nombre = TFNombre.getText();
        String contraseña = TFContraseña.getText();
        String rol = CBRol.getValue();
        if (db.createUser(rol, nombre, contraseña)) { 
            JOptionPane.showMessageDialog(null, "Empleado agregado correctamente");
            TFNombre.setText("");
            TFContraseña.setText("");
        } else {
            JOptionPane.showMessageDialog(null, "Error al agregar al empleado",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
